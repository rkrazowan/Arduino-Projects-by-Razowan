# WiFiTank
This repository contains code and diagram for wifi tank using esp32 and smartphone
